package com.aspire.travelexploration.util;

public interface MySql {
	public static final String MY_SQL_driverName = "com.mysql.jdbc.Driver";
	public static final String userName = "user";
	public static final String MY_SQL_username = "root";
	public static final String password = "password";
	public static final String MY_SQL_password = "aspire@123";
	public static final String MY_SQL_url = "jdbc:mysql://localhost:3306/wanderlust";
}
