package com.aspire.travelexploration.enums;

public enum FlightE {
	ECONOMY,BUSINESS,PREMIUMECONOMY,FIRSTCLASS;
}
