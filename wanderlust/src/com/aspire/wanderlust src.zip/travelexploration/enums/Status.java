package com.aspire.travelexploration.enums;

public enum Status {
	CONFIRMED,UNCONFIRMED,CANCELLED;
}
