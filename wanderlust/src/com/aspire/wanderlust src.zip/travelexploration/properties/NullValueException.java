package com.aspire.travelexploration.properties;

public class NullValueException extends Exception{
	public NullValueException(String errorMessage) {
	}
}
