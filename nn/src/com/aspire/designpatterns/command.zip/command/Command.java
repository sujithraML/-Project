package com.aspire.designpatterns.command;

public interface Command {
	public void excecute();
}
