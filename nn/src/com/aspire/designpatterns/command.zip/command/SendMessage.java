package com.aspire.designpatterns.command;

public class SendMessage implements Command{
	String message;
	
	Receiver receiver;
	
	SendMessage(){
		
	}
	SendMessage(String message){
		this.message = message;
	}
	@Override
	public void excecute() {
	//	receiver.setMessage(message);
	//	receiver.sendInfo();
	}
}
