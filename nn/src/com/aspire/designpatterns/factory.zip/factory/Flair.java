package com.aspire.designpatterns.factory;

public class Flair {
	Flair(){
		
	}
	static String logo="Flair";
	
	public void write() {
		
	}
}
