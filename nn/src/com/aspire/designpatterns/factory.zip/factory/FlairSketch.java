package com.aspire.designpatterns.factory;

public class FlairSketch extends Flair{
	int nibThickness;
	
	public void write() {
		System.out.println(logo+"\tArial Bold");
	}
}
