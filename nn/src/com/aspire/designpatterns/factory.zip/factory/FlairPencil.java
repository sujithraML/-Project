package com.aspire.designpatterns.factory;

public class FlairPencil extends Flair{
	int nibThickness;
	
	public void write() {
		System.out.println(logo+"\tLato thin");
	}
}
