package com.aspire.designpatterns.proxy;

public interface Printablee {
	public void printt();
}
