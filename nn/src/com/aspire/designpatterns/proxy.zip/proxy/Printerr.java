package com.aspire.designpatterns.proxy;

public class Printerr  implements Printablee{

	@Override
	public void printt() {
		System.out.println("Printed");
	}

}
