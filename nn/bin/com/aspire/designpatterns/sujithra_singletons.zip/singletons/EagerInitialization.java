package com.aspire.designpatterns.singletons;

public class EagerInitialization {
	private static EagerInitialization object = new EagerInitialization();
	private static String string;
	private EagerInitialization() {
		
	}
	/*thread-safe:can be used when the class is simple*/
	public static EagerInitialization getInstance() {
		return object;
	}
	{
		string = new String("Static Block");
	}
}
