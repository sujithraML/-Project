package com.aspire.designpatterns.singletons;

public interface Initializable {
	public Object getInstance();
}
