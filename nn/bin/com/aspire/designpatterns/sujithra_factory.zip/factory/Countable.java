package com.aspire.designpatterns.factory;

public interface Countable {
	public Counter getCount();
}
