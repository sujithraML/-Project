package com.aspire.designpatterns.factory;

public class PageCounter implements Countable{
	private Counter counter;
	
	PageCounter(String count){
		this.counter=new Counter(count);
	}

	@Override
	public Counter getCount() {
		return counter;
	}
}
