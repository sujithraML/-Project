package com.aspire.designpatterns.factory;

public class Counter {
	private String count;
	
	public Counter(String count) {
		this.count = count;
	}
	public String toString() {
		return count;
	}
}
