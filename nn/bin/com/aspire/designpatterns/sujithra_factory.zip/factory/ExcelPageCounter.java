package com.aspire.designpatterns.factory;

public class ExcelPageCounter implements Countable{

	@Override
	public Counter getCount() {
		return null;
	}

}
