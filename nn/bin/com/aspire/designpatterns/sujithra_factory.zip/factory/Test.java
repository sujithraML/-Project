package com.aspire.designpatterns.factory;

public class Test {
	public static void main(String[] args) {
		Counter counter;
		Countable countable = null;
		countable = new PageCounter("10");
		counter=countable.getCount();
		System.out.println(counter);
	}
}
